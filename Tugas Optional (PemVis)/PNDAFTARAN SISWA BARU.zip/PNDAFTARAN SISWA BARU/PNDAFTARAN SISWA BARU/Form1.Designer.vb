﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.txttempat = New System.Windows.Forms.TextBox()
        Me.dt1 = New System.Windows.Forms.TextBox()
        Me.txtasal = New System.Windows.Forms.TextBox()
        Me.txtalamat = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PendaftaranDataSet = New PNDAFTARAN_SISWA_BARU.pendaftaranDataSet()
        Me.PendaftaranBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PendaftaranTableAdapter = New PNDAFTARAN_SISWA_BARU.pendaftaranDataSetTableAdapters.pendaftaranTableAdapter()
        Me.IdpendaftaranDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TempatlahirDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TanggallahirDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AsalsekolahDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AlamatpendaftaranDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PendaftaranDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PendaftaranBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(201, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID PENDAFTARAN            :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(203, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "NAMA                                    :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(201, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "TEMPAT LAHIR                  :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(37, 178)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(203, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "TANGGAL LAHIR               :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(37, 219)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(203, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "ASAL SEKOLAH                 :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(37, 262)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(204, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "ALAMAT PENDAFTARAN :"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(240, 57)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(302, 26)
        Me.txtid.TabIndex = 6
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(240, 98)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(302, 26)
        Me.txtnama.TabIndex = 7
        '
        'txttempat
        '
        Me.txttempat.Location = New System.Drawing.Point(240, 138)
        Me.txttempat.Name = "txttempat"
        Me.txttempat.Size = New System.Drawing.Size(302, 26)
        Me.txttempat.TabIndex = 8
        '
        'dt1
        '
        Me.dt1.Location = New System.Drawing.Point(240, 178)
        Me.dt1.Name = "dt1"
        Me.dt1.Size = New System.Drawing.Size(302, 26)
        Me.dt1.TabIndex = 9
        '
        'txtasal
        '
        Me.txtasal.Location = New System.Drawing.Point(240, 219)
        Me.txtasal.Name = "txtasal"
        Me.txtasal.Size = New System.Drawing.Size(302, 26)
        Me.txtasal.TabIndex = 10
        '
        'txtalamat
        '
        Me.txtalamat.Location = New System.Drawing.Point(240, 256)
        Me.txtalamat.Name = "txtalamat"
        Me.txtalamat.Size = New System.Drawing.Size(302, 26)
        Me.txtalamat.TabIndex = 11
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(50, 315)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 31)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "SIMPAN"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(221, 315)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(108, 31)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "EDIT"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(390, 315)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 31)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "HAPUS"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IdpendaftaranDataGridViewTextBoxColumn, Me.NamaDataGridViewTextBoxColumn, Me.TempatlahirDataGridViewTextBoxColumn, Me.TanggallahirDataGridViewTextBoxColumn, Me.AsalsekolahDataGridViewTextBoxColumn, Me.AlamatpendaftaranDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.PendaftaranBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(43, 385)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(625, 182)
        Me.DataGridView1.TabIndex = 15
        '
        'PendaftaranDataSet
        '
        Me.PendaftaranDataSet.DataSetName = "pendaftaranDataSet"
        Me.PendaftaranDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PendaftaranBindingSource
        '
        Me.PendaftaranBindingSource.DataMember = "pendaftaran"
        Me.PendaftaranBindingSource.DataSource = Me.PendaftaranDataSet
        '
        'PendaftaranTableAdapter
        '
        Me.PendaftaranTableAdapter.ClearBeforeFill = True
        '
        'IdpendaftaranDataGridViewTextBoxColumn
        '
        Me.IdpendaftaranDataGridViewTextBoxColumn.DataPropertyName = "id_pendaftaran"
        Me.IdpendaftaranDataGridViewTextBoxColumn.HeaderText = "id_pendaftaran"
        Me.IdpendaftaranDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.IdpendaftaranDataGridViewTextBoxColumn.Name = "IdpendaftaranDataGridViewTextBoxColumn"
        Me.IdpendaftaranDataGridViewTextBoxColumn.Width = 150
        '
        'NamaDataGridViewTextBoxColumn
        '
        Me.NamaDataGridViewTextBoxColumn.DataPropertyName = "nama"
        Me.NamaDataGridViewTextBoxColumn.HeaderText = "nama"
        Me.NamaDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.NamaDataGridViewTextBoxColumn.Name = "NamaDataGridViewTextBoxColumn"
        Me.NamaDataGridViewTextBoxColumn.Width = 150
        '
        'TempatlahirDataGridViewTextBoxColumn
        '
        Me.TempatlahirDataGridViewTextBoxColumn.DataPropertyName = "tempat_lahir"
        Me.TempatlahirDataGridViewTextBoxColumn.HeaderText = "tempat_lahir"
        Me.TempatlahirDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.TempatlahirDataGridViewTextBoxColumn.Name = "TempatlahirDataGridViewTextBoxColumn"
        Me.TempatlahirDataGridViewTextBoxColumn.Width = 150
        '
        'TanggallahirDataGridViewTextBoxColumn
        '
        Me.TanggallahirDataGridViewTextBoxColumn.DataPropertyName = "tanggal_lahir"
        Me.TanggallahirDataGridViewTextBoxColumn.HeaderText = "tanggal_lahir"
        Me.TanggallahirDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.TanggallahirDataGridViewTextBoxColumn.Name = "TanggallahirDataGridViewTextBoxColumn"
        Me.TanggallahirDataGridViewTextBoxColumn.Width = 150
        '
        'AsalsekolahDataGridViewTextBoxColumn
        '
        Me.AsalsekolahDataGridViewTextBoxColumn.DataPropertyName = "asal_sekolah"
        Me.AsalsekolahDataGridViewTextBoxColumn.HeaderText = "asal_sekolah"
        Me.AsalsekolahDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.AsalsekolahDataGridViewTextBoxColumn.Name = "AsalsekolahDataGridViewTextBoxColumn"
        Me.AsalsekolahDataGridViewTextBoxColumn.Width = 150
        '
        'AlamatpendaftaranDataGridViewTextBoxColumn
        '
        Me.AlamatpendaftaranDataGridViewTextBoxColumn.DataPropertyName = "alamat_pendaftaran"
        Me.AlamatpendaftaranDataGridViewTextBoxColumn.HeaderText = "alamat_pendaftaran"
        Me.AlamatpendaftaranDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.AlamatpendaftaranDataGridViewTextBoxColumn.Name = "AlamatpendaftaranDataGridViewTextBoxColumn"
        Me.AlamatpendaftaranDataGridViewTextBoxColumn.Width = 150
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(701, 589)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtalamat)
        Me.Controls.Add(Me.txtasal)
        Me.Controls.Add(Me.dt1)
        Me.Controls.Add(Me.txttempat)
        Me.Controls.Add(Me.txtnama)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Pendaftaran Siswa Baru"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PendaftaranDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PendaftaranBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtid As TextBox
    Friend WithEvents txtnama As TextBox
    Friend WithEvents txttempat As TextBox
    Friend WithEvents dt1 As TextBox
    Friend WithEvents txtasal As TextBox
    Friend WithEvents txtalamat As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents PendaftaranDataSet As pendaftaranDataSet
    Friend WithEvents PendaftaranBindingSource As BindingSource
    Friend WithEvents PendaftaranTableAdapter As pendaftaranDataSetTableAdapters.pendaftaranTableAdapter
    Friend WithEvents IdpendaftaranDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TempatlahirDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TanggallahirDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AsalsekolahDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AlamatpendaftaranDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
