﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PendaftaranDataSet.pendaftaran' table. You can move, or remove it, as needed.
        Me.PendaftaranTableAdapter.Fill(Me.PendaftaranDataSet.pendaftaran)

    End Sub
End Class
