﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.DataBarangBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Pengirimanbarang1 = New PENGIRIMAN_BARANG1.pengirimanbarang1()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.simpan = New System.Windows.Forms.Button()
        Me.hapus = New System.Windows.Forms.Button()
        Me.keluar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Data_barangTableAdapter = New PENGIRIMAN_BARANG1.pengirimanbarang1TableAdapters.data_barangTableAdapter()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.KodebarangDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KurirDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PelayananDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PengirimDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TujuanDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BeratDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataBarangBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pengirimanbarang1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataBarangBindingSource
        '
        Me.DataBarangBindingSource.DataMember = "data barang"
        Me.DataBarangBindingSource.DataSource = Me.Pengirimanbarang1
        '
        'Pengirimanbarang1
        '
        Me.Pengirimanbarang1.DataSetName = "pengirimanbarang1"
        Me.Pengirimanbarang1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(210, 47)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(326, 26)
        Me.TextBox1.TabIndex = 1
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(210, 106)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(326, 26)
        Me.TextBox2.TabIndex = 2
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(210, 166)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(326, 26)
        Me.TextBox3.TabIndex = 3
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(210, 227)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(326, 26)
        Me.TextBox4.TabIndex = 4
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(210, 285)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(326, 26)
        Me.TextBox5.TabIndex = 5
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(210, 340)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(326, 26)
        Me.TextBox6.TabIndex = 6
        '
        'simpan
        '
        Me.simpan.Location = New System.Drawing.Point(878, 47)
        Me.simpan.Name = "simpan"
        Me.simpan.Size = New System.Drawing.Size(125, 49)
        Me.simpan.TabIndex = 7
        Me.simpan.Text = "SIMPAN"
        Me.simpan.UseVisualStyleBackColor = True
        '
        'hapus
        '
        Me.hapus.Location = New System.Drawing.Point(878, 143)
        Me.hapus.Name = "hapus"
        Me.hapus.Size = New System.Drawing.Size(125, 49)
        Me.hapus.TabIndex = 8
        Me.hapus.Text = "HAPUS"
        Me.hapus.UseVisualStyleBackColor = True
        '
        'keluar
        '
        Me.keluar.Location = New System.Drawing.Point(878, 233)
        Me.keluar.Name = "keluar"
        Me.keluar.Size = New System.Drawing.Size(125, 49)
        Me.keluar.TabIndex = 9
        Me.keluar.Text = "KELUAR"
        Me.keluar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 20)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "KODE BARANG"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 20)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "KURIR"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 172)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 20)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "PELAYANAN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 233)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "PENGIRIM"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 291)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 20)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "PENERIMA"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 346)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 20)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "BERAT BARANG"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 437)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(125, 20)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "DATA BARANG"
        '
        'Data_barangTableAdapter
        '
        Me.Data_barangTableAdapter.ClearBeforeFill = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.KodebarangDataGridViewTextBoxColumn, Me.KurirDataGridViewTextBoxColumn, Me.PelayananDataGridViewTextBoxColumn, Me.PengirimDataGridViewTextBoxColumn, Me.TujuanDataGridViewTextBoxColumn, Me.BeratDataGridViewTextBoxColumn})
        Me.DataGridView2.DataSource = Me.DataBarangBindingSource
        Me.DataGridView2.Location = New System.Drawing.Point(210, 437)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersWidth = 62
        Me.DataGridView2.RowTemplate.Height = 28
        Me.DataGridView2.Size = New System.Drawing.Size(934, 234)
        Me.DataGridView2.TabIndex = 18
        '
        'KodebarangDataGridViewTextBoxColumn
        '
        Me.KodebarangDataGridViewTextBoxColumn.DataPropertyName = "Kode_barang"
        Me.KodebarangDataGridViewTextBoxColumn.HeaderText = "Kode_barang"
        Me.KodebarangDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.KodebarangDataGridViewTextBoxColumn.Name = "KodebarangDataGridViewTextBoxColumn"
        Me.KodebarangDataGridViewTextBoxColumn.Width = 150
        '
        'KurirDataGridViewTextBoxColumn
        '
        Me.KurirDataGridViewTextBoxColumn.DataPropertyName = "Kurir"
        Me.KurirDataGridViewTextBoxColumn.HeaderText = "Kurir"
        Me.KurirDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.KurirDataGridViewTextBoxColumn.Name = "KurirDataGridViewTextBoxColumn"
        Me.KurirDataGridViewTextBoxColumn.Width = 150
        '
        'PelayananDataGridViewTextBoxColumn
        '
        Me.PelayananDataGridViewTextBoxColumn.DataPropertyName = "Pelayanan"
        Me.PelayananDataGridViewTextBoxColumn.HeaderText = "Pelayanan"
        Me.PelayananDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.PelayananDataGridViewTextBoxColumn.Name = "PelayananDataGridViewTextBoxColumn"
        Me.PelayananDataGridViewTextBoxColumn.Width = 150
        '
        'PengirimDataGridViewTextBoxColumn
        '
        Me.PengirimDataGridViewTextBoxColumn.DataPropertyName = "Pengirim"
        Me.PengirimDataGridViewTextBoxColumn.HeaderText = "Pengirim"
        Me.PengirimDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.PengirimDataGridViewTextBoxColumn.Name = "PengirimDataGridViewTextBoxColumn"
        Me.PengirimDataGridViewTextBoxColumn.Width = 150
        '
        'TujuanDataGridViewTextBoxColumn
        '
        Me.TujuanDataGridViewTextBoxColumn.DataPropertyName = "Tujuan"
        Me.TujuanDataGridViewTextBoxColumn.HeaderText = "Tujuan"
        Me.TujuanDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.TujuanDataGridViewTextBoxColumn.Name = "TujuanDataGridViewTextBoxColumn"
        Me.TujuanDataGridViewTextBoxColumn.Width = 150
        '
        'BeratDataGridViewTextBoxColumn
        '
        Me.BeratDataGridViewTextBoxColumn.DataPropertyName = "Berat"
        Me.BeratDataGridViewTextBoxColumn.HeaderText = "Berat"
        Me.BeratDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.BeratDataGridViewTextBoxColumn.Name = "BeratDataGridViewTextBoxColumn"
        Me.BeratDataGridViewTextBoxColumn.Width = 150
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1190, 683)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.keluar)
        Me.Controls.Add(Me.hapus)
        Me.Controls.Add(Me.simpan)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "FORM INPUT DATA"
        CType(Me.DataBarangBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pengirimanbarang1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents simpan As Button
    Friend WithEvents hapus As Button
    Friend WithEvents keluar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Pengirimanbarang1 As pengirimanbarang1
    Friend WithEvents DataBarangBindingSource As BindingSource
    Friend WithEvents Data_barangTableAdapter As pengirimanbarang1TableAdapters.data_barangTableAdapter
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents KodebarangDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents KurirDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PelayananDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PengirimDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TujuanDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BeratDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
